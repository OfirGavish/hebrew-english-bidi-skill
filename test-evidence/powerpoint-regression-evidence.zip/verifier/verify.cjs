const fs = require("node:fs/promises");
const path = require("node:path");
const crypto = require("node:crypto");
const { isDeepStrictEqual } = require("node:util");
const JSZip = require("jszip");
const { DOMParser, XMLSerializer } = require("@xmldom/xmldom");

const namespaces = {
  w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
  a: "http://schemas.openxmlformats.org/drawingml/2006/main",
  p: "http://schemas.openxmlformats.org/presentationml/2006/main",
  rel: "http://schemas.openxmlformats.org/package/2006/relationships",
};
const elements = (node, ns, name) => Array.from(node.getElementsByTagNameNS(ns, name));
const direct = (node, ns, name) => Array.from(node.childNodes ?? [])
  .find((child) => child.namespaceURI === ns && child.localName === name) ?? null;
const serialize = (node) => new XMLSerializer().serializeToString(node);
const digest = (data) => crypto.createHash("sha256").update(data).digest("hex");
const attr = (node, ns, name) => node?.getAttributeNS(ns, name) ?? "";
const on = (value) => !["0", "false", "off"].includes(value);

function readXml(text, label) {
  return new DOMParser({ onError(level, message) {
    throw new Error(`XML ${level} in ${label}: ${message}`);
  } }).parseFromString(text, "application/xml");
}

function normalized(node) {
  if (node.nodeType === 3) return node.nodeValue.trim() ? node.nodeValue : null;
  if (node.nodeType !== 1) return null;
  return {
    name: `${node.namespaceURI}:${node.localName}`,
    attributes: Array.from(node.attributes)
      .filter((a) => a.namespaceURI !== "http://www.w3.org/2000/xmlns/")
      .map((a) => [`${a.namespaceURI}:${a.localName}`, a.value])
      .sort(([a], [b]) => a.localeCompare(b)),
    children: Array.from(node.childNodes).map(normalized).filter((n) => n !== null),
  };
}

function runStyle(run, ns) {
  const properties = direct(run, ns, "rPr");
  if (!properties) return null;
  const copy = properties.cloneNode(true);
  for (const child of Array.from(copy.childNodes)) {
    if (child.nodeType === 1 && ["rtl", "lang", "hlinkClick", "hlinkMouseOver"].includes(child.localName)) {
      copy.removeChild(child);
    }
  }
  for (const attribute of Array.from(copy.attributes)) {
    if (["lang", "altLang", "dirty", "smtClean", "err", "noProof"].includes(attribute.localName)) {
      copy.removeAttributeNode(attribute);
    }
  }
  return normalized(copy);
}

async function snapshot(filename) {
  const buffer = await fs.readFile(filename);
  const zip = await JSZip.loadAsync(buffer, { checkCRC32: true });
  const extension = path.extname(filename).slice(1).toLowerCase();
  if (!["docx", "pptx"].includes(extension)) throw new Error("Expected .docx or .pptx");
  const ns = namespaces[extension === "docx" ? "w" : "a"];
  const result = {
    extension, sha256: digest(buffer), paragraphs: [], links: [], geometry: [],
    numbering: [], media: [], presentationLayout: [], protectedParts: [], xmlParts: 0,
  };
  const partPattern = extension === "docx"
    ? /^word\/(?:document|header[^/]*|footer[^/]*|footnotes|endnotes)\.xml$/
    : /^ppt\/(?:slides\/slide\d+|notesSlides\/notesSlide\d+)\.xml$/;
  for (const name of Object.keys(zip.files).sort()) {
    const entry = zip.file(name);
    if (!entry) continue;
    if (extension === "pptx" && /^ppt\/(slideMasters|slideLayouts|notesMasters|theme)\//.test(name)) {
      result.protectedParts.push({ name, sha256: digest(await entry.async("nodebuffer")) });
    }
    if (/^(word|ppt)\/media\//.test(name)) {
      result.media.push({ name, sha256: digest(await entry.async("nodebuffer")) });
    }
    if (!/\.(xml|rels)$/.test(name)) continue;
    const document = readXml(await entry.async("string"), name);
    result.xmlParts++;
    if (extension === "pptx" && name === "ppt/presentation.xml") {
      for (const localName of ["sldIdLst", "sldSz", "notesSz"]) {
        for (const item of elements(document, namespaces.p, localName)) {
          result.presentationLayout.push(normalized(item));
        }
      }
    }
    if (name.endsWith(".rels")) {
      for (const rel of elements(document, namespaces.rel, "Relationship")) {
        if (rel.getAttribute("Type").endsWith("/hyperlink")) {
          result.links.push({
            part: name, target: rel.getAttribute("Target"), mode: rel.getAttribute("TargetMode"),
          });
        }
      }
    }
    if (name === "word/numbering.xml") result.numbering = normalized(document.documentElement);
    if (!partPattern.test(name)) continue;
    for (const [index, p] of elements(document, ns, "p").entries()) {
      const propertyNodes = Array.from(p.childNodes)
        .filter((node) => node.namespaceURI === ns && node.localName === "pPr");
      if (propertyNodes.length > 1) throw new Error(`Duplicate paragraph properties in ${name}, paragraph ${index}`);
      const text = elements(p, ns, "t").map((node) => node.textContent).join("");
      const properties = direct(p, ns, "pPr");
      const rtlProperty = extension === "docx" ? direct(properties ?? p, ns, "bidi") : null;
      const rtl = extension === "docx"
        ? !!rtlProperty && on(attr(rtlProperty, ns, "val"))
        : properties?.getAttribute("rtl") === "1";
      const rawAlignment = extension === "docx"
        ? attr(direct(properties ?? p, ns, "jc"), ns, "val")
        : properties?.getAttribute("algn") ?? "";
      // Word's transitional left/right values are paragraph-relative under bidi.
      const alignment = extension === "docx"
        ? ({ left: rtl ? "right" : "left", right: rtl ? "left" : "right",
          start: rtl ? "right" : "left", end: rtl ? "left" : "right" })[rawAlignment] ?? rawAlignment
        : rawAlignment;
      const characters = [];
      const englishRtlRuns = [];
      let terminalPunctuationRtl = null;
      for (const run of elements(p, ns, "r")) {
        const runText = elements(run, ns, "t").map((node) => node.textContent).join("");
        const style = runStyle(run, ns);
        for (const character of Array.from(runText)) characters.push({ character, style });
        const rPr = direct(run, ns, "rPr");
        const override = direct(rPr ?? run, ns, "rtl");
        if (runText) {
          terminalPunctuationRtl = override
            ? on(extension === "docx" ? attr(override, ns, "val") : override.getAttribute("val"))
            : null;
        }
        if (override && on(extension === "docx"
          ? attr(override, ns, "val") : override.getAttribute("val"))) {
          if (/[A-Za-z]/.test(runText) && !/[\u0590-\u05ff]/.test(runText)) {
            englishRtlRuns.push(runText);
          }
        }
      }
      result.paragraphs.push({
        part: name, index, text, rtl, alignment, rawAlignment, characters, englishRtlRuns, terminalPunctuationRtl,
        directionMarkupCounts: {
          paragraph: extension === "docx" ? elements(p, ns, "bidi").length : Number(properties?.hasAttribute("rtl") ?? false),
          runs: elements(p, ns, "rtl").length,
          isolationWrappers: extension === "docx" ? elements(p, ns, "dir").length : 0,
          overrideWrappers: extension === "docx" ? elements(p, ns, "bdo").length : 0,
        },
        numbering: extension === "docx" ? normalized(direct(properties ?? p, ns, "numPr") ?? p.ownerDocument.createElement("none")) : null,
      });
    }
    const names = extension === "docx"
      ? ["pgSz", "pgMar", "tblGrid", "tblW", "tcW"]
      : ["xfrm", "gridCol", "tr"];
    for (const localName of names) {
      const geometryNs = extension === "docx" ? namespaces.w : namespaces.a;
      for (const item of elements(document, geometryNs, localName)) {
        const copy = item.cloneNode(true);
        if (localName === "tr") while (copy.firstChild) copy.removeChild(copy.firstChild);
        result.geometry.push({ part: name, value: normalized(copy) });
      }
    }
    if (extension === "pptx") {
      for (const item of elements(document, namespaces.p, "xfrm")) {
        result.geometry.push({ part: name, value: normalized(item) });
      }
      for (const shape of elements(document, namespaces.p, "sp")) {
        const properties = direct(shape, namespaces.p, "spPr");
        if (properties) result.geometry.push({ part: name, kind: "shape-properties", value: normalized(properties) });
      }
      for (const properties of elements(document, namespaces.a, "pPr")) {
        const list = properties.cloneNode(true);
        for (const attribute of Array.from(list.attributes)) {
          if (!["lvl", "marL", "marR", "indent"].includes(attribute.localName)) list.removeAttributeNode(attribute);
        }
        for (const child of Array.from(list.childNodes)) {
          if (child.nodeType !== 1 || !child.localName.startsWith("bu")) list.removeChild(child);
        }
        const value = normalized(list);
        if (value.attributes.length || value.children.length) result.numbering.push({ part: name, value });
      }
      for (const nameTag of ["sp", "graphicFrame", "pic", "grpSp"]) {
        result.geometry.push({ part: name, kind: nameTag, count: elements(document, namespaces.p, nameTag).length });
      }
    }
  }
  result.links.sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
  return result;
}

function compare(baseline, output, cases) {
  const failures = [];
  const review = [];
  const key = (p) => `${p.part}#${p.index}`;
  const before = baseline.paragraphs.map((p) => [key(p), p.text]);
  const after = output.paragraphs.map((p) => [key(p), p.text]);
  if (!isDeepStrictEqual(before, after)) failures.push("Exact paragraph text/order changed, including notes, headers or footers.");
  for (const property of ["links", "geometry", "numbering", "media", "presentationLayout", "protectedParts"]) {
    if (!isDeepStrictEqual(baseline[property], output[property])) {
      review.push(`${property} changed; inspect whether the change is semantically equivalent or a preservation regression.`);
    }
  }
  for (const p of baseline.paragraphs) {
    const other = output.paragraphs.find((candidate) => key(candidate) === key(p));
    if (other && /[A-Za-z]/.test(p.text) && !/[\u0590-\u05ff]/.test(p.text) && !p.rtl && other.rtl) {
      failures.push(`English-only control changed to RTL at ${key(p)}.`);
    }
    if (other && !isDeepStrictEqual(p.characters, other.characters)) {
      review.push(`Explicit run formatting changed at ${key(p)}; inspect inherited/equivalent formatting before deciding.`);
    }
  }
  const applicable = cases.filter((c) => baseline.extension === "docx" ? !c.pptOnly : !c.wordOnly);
  const caseResults = applicable.map((c) => {
    const matches = output.paragraphs.filter((p) => p.text === c.text);
    const problems = [];
    if (matches.length !== 1) problems.push(`Expected exactly one case paragraph, found ${matches.length}.`);
    if (matches.length === 1) {
      const p = matches[0];
      if (p.rtl !== c.rtl) problems.push(`Expected local ${c.rtl ? "RTL" : "LTR"} paragraph direction.`);
      const expected = c.align === "center" ? ["center", "ctr"]
        : c.rtl ? ["right", "r"] : ["left", "l"];
      if (p.alignment === "") {
        review.push(`${c.id}: paragraph alignment is inherited; resolve it in the native application.`);
      } else if (!expected.includes(p.alignment)) {
        problems.push(`Expected ${c.align ?? (c.rtl ? "right" : "left")} alignment.`);
      }
      if (p.englishRtlRuns.length) problems.push("Strong English runs have explicit RTL overrides.");
      if (output.extension === "docx" && c.rtl && c.text.endsWith(".") && p.terminalPunctuationRtl !== true) {
        review.push(`${c.id}: Hebrew sentence-ending punctuation has no explicit RTL run context; native visual boundary verification is required.`);
      }
    }
    if (problems.length) failures.push(`${c.id}: ${problems.join(" ")}`);
    return { id: c.id, status: problems.length ? "FAIL" : "PASS", problems };
  });
  return {
    structuralStatus: failures.length ? "FAIL" : review.length ? "NEEDS_REVIEW" : "PASS",
    visualStatus: "NOT_ASSESSED",
    skillActivationStatus: "NOT_ASSESSED",
    inputSha256: baseline.sha256, outputSha256: output.sha256,
    cases: caseResults, failures, preservationReview: review,
    limitation: "Direction checks require local paragraph properties. Style/master inheritance changes need manual review. A structural pass is not proof of correct rendering or custom-skill activation.",
  };
}

function idempotency(first, second) {
  const clean = ({ sha256, xmlParts, ...rest }) => rest;
  return {
    status: isDeepStrictEqual(clean(first), clean(second)) ? "PASS" : "NEEDS_REVIEW",
    criterion: "Semantic snapshot equality: text, directions, alignment, explicit formatting, links, geometry, numbering, and media; ZIP bytes and volatile package metadata ignored.",
  };
}

async function main() {
  const [filename, repeat] = process.argv.slice(2);
  if (!filename) throw new Error("Usage: node verify.cjs <repaired.docx|repaired.pptx> [second-pass-file]");
  const baseline = JSON.parse(await fs.readFile(path.join(__dirname, "oracle", "baseline.json"), "utf8"));
  const cases = JSON.parse(await fs.readFile(path.join(__dirname, "oracle", "cases.json"), "utf8"));
  const output = await snapshot(filename);
  const report = compare(baseline[output.extension], output, cases);
  if (repeat) report.idempotency = idempotency(output, await snapshot(repeat));
  console.log(JSON.stringify(report, null, 2));
  if (report.structuralStatus !== "PASS" || (report.idempotency && report.idempotency.status !== "PASS")) process.exitCode = 1;
}

module.exports = { snapshot, compare, idempotency, readXml, elements, direct, serialize, namespaces };
if (require.main === module) main().catch((error) => { console.error(error); process.exitCode = 1; });
